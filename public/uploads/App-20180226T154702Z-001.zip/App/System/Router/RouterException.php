<?php
namespace App\System\Router;
use \Exception;

class RouterException extends Exception {

}
